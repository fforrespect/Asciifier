
GREYS: tuple[*str]
IMAGE_STORE_FP: str
