import _constants

_constants.GREYS = (' ', '.', '-', '"', 'r', '/', '>', ')', '[', 'I', 'Y', 'Z', 'h', '#', '8', '@')
_constants.IMAGE_STORE_FP = "../imageStore/image.jpg"
