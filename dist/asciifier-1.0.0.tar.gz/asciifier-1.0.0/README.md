This is a module that will take any image file and convert it to ASCII art.

It can either return the ASCII Art string, or print it in place.