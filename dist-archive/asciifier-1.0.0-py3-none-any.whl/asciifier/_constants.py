
GREYS: tuple
IMAGE_STORE_FP: str
